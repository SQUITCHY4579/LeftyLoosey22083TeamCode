package com.example.meepmeeptesting;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;

import org.rowlandhall.meepmeep.MeepMeep;
import org.rowlandhall.meepmeep.roadrunner.DefaultBotBuilder;
import org.rowlandhall.meepmeep.roadrunner.entity.RoadRunnerBotEntity;

public class MeepMeepTesting {
    public static void main(String[] args) {
        MeepMeep meepMeep = new MeepMeep(700);



        RoadRunnerBotEntity myBot = new DefaultBotBuilder(meepMeep)
                // Set bot constraints: maxVel, maxAccel, maxAngVel, maxAngAccel, track width

                .setConstraints(52, 52, Math.toRadians(231.31152), Math.toRadians(231.31152), 11.55)
                .followTrajectorySequence(drive -> drive.trajectorySequenceBuilder(new Pose2d(-34.57, -62.59, Math.toRadians(0.00)))
                                .lineToConstantHeading(new Vector2d(-44.18, -62.39))
                                .splineToLinearHeading(new Pose2d(-49.09, -44.39, Math.toRadians(90.00)), Math.toRadians(123.14))
                                .lineToLinearHeading(new Pose2d(-50.30, -55.98, Math.toRadians(40.00)))
                                .splineToLinearHeading(new Pose2d(-58.91, -44.39, Math.toRadians(90.00)), Math.toRadians(109.09))
                                .lineToLinearHeading(new Pose2d(-56.59, -50.30, Math.toRadians(55.00)))
                                .splineToLinearHeading(new Pose2d(-51.34, -26.80, Math.toRadians(180.00)), Math.toRadians(128.37))
                                .lineToLinearHeading(new Pose2d(-52.73, -52.53, Math.toRadians(45.00)))
                                .splineToLinearHeading(new Pose2d(-42.55, -10, Math.toRadians(180.00)), Math.toRadians(10.00))
                                .lineTo(new Vector2d(-31.03, -10))

                                .build());



        meepMeep.setBackground(MeepMeep.Background.FIELD_INTOTHEDEEP_JUICE_DARK)
                .setDarkMode(true)
                .setBackgroundAlpha(0.95f)
                .addEntity(myBot)
                .start();
    }
}