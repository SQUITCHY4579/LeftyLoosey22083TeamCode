package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.drive.DriveConstants;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequenceBuilder;

@Config
@Autonomous
public class NewRightAutonomous extends LinearOpMode {
    private DcMotor rightViperslide, leftViperslide;

    // Servos
    private Servo leftExtension, rightExtension, intakeClaw, rightIntakeFlipper, leftIntakeFlipper, slapshot;
    private Servo leftVSFlipper, rightVSFlipper, outputClawLeft, outputClawRight, outputWrist, intakeWrist;


    private double viperslideInitialPosition;

    public void closeOutputClaw() {
        outputClawRight.setPosition(0.67);
        outputClawLeft.setPosition(0.33);
    }
    public void openOutputClaw() {
        outputClawRight.setPosition(0.9);
        outputClawLeft.setPosition(0.1);
    }
    public void retractExtensionServos() {
        leftExtension.setPosition(0.07);
        rightExtension.setPosition(0.95);
    }
    public void flipIntakeUp() {
        leftIntakeFlipper.setPosition(0.94); //flip intake up
        rightIntakeFlipper.setPosition(0.06);
        intakeWrist.setPosition(0.08);
    }
    public void closeIntakeClaw() {
        intakeClaw.setPosition(0.5);
    }
    public void openIntakeClaw() {
        intakeClaw.setPosition(0.8);
    }
    public void flipOutputOut() {
        outputWrist.setPosition(0.41);
        leftVSFlipper.setPosition(0.04); //flip output claw half
        //sleep(12);
        rightVSFlipper.setPosition(0.8);
    }
    public void flipOutputIn() {
        closeOutputClaw();
        outputWrist.setPosition(0.6);
        leftVSFlipper.setPosition(0.54);
        //sleep(12);
        rightVSFlipper.setPosition (0.3);
    }
    public void flipOutputSpecimenOut() {
        outputWrist.setPosition(0.67);
        leftVSFlipper.setPosition(0.07); //flip output claw half
        //sleep(12);
        rightVSFlipper.setPosition(0.77); //+0.04
    }
    public void flipOutputBucketOut() {
        outputWrist.setPosition(0.18);
        leftVSFlipper.setPosition(0.32);
        //sleep(12);
        rightVSFlipper.setPosition(0.6);
    }
    public void extendExtensionServos() {
        leftExtension.setPosition(0.32);
        rightExtension.setPosition(0.7);
    }
    public void flipIntakeDown() {
        leftIntakeFlipper.setPosition(0.04); //flip intake down
        rightIntakeFlipper.setPosition(0.96);
    }
    public void flipIntakePartialDown() {
        leftIntakeFlipper.setPosition(0.17); //flip intake partial down
        rightIntakeFlipper.setPosition(0.83);
    }
    public void extendViperslide(int targetPosition) {
        rightViperslide.setTargetPosition((int)viperslideInitialPosition + targetPosition);
        leftViperslide.setTargetPosition((int)viperslideInitialPosition + targetPosition);
        rightViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightViperslide.setPower(0.7);
        leftViperslide.setPower(0.7);
    }


    @Override
    public void runOpMode() throws InterruptedException {
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap, 0.17);
        rightViperslide = hardwareMap.get(DcMotor.class, "rightViperslide");
        leftViperslide = hardwareMap.get(DcMotor.class, "leftViperslide");

        leftViperslide.setDirection(DcMotor.Direction.REVERSE);

        outputClawLeft = hardwareMap.get(Servo.class, "outputClawLeft");
        outputClawRight = hardwareMap.get(Servo.class, "outputClawRight");
        rightVSFlipper = hardwareMap.get(Servo.class, "rightVSFlipper");
        leftVSFlipper = hardwareMap.get(Servo.class, "leftVSFlipper");
        leftExtension = hardwareMap.get(Servo.class, "leftExtension");
        rightExtension = hardwareMap.get(Servo.class, "rightExtension");
        rightIntakeFlipper = hardwareMap.get(Servo.class, "rightIntakeFlipper");
        leftIntakeFlipper = hardwareMap.get(Servo.class, "leftIntakeFlipper");
        intakeClaw = hardwareMap.get(Servo.class, "intakeClaw");
        slapshot = hardwareMap.get(Servo.class, "slapshot");
        intakeWrist = hardwareMap.get(Servo.class, "intakeWrist");
        outputWrist = hardwareMap.get(Servo.class, "outputWrist");


        // Set viper slide motors to hold position
        rightViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        leftViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        leftViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        viperslideInitialPosition = rightViperslide.getCurrentPosition();


        Pose2d startPose = new Pose2d(8.92, -62.06, Math.toRadians(270.00));
        drive.setPoseEstimate(startPose);

        TrajectorySequence trajectory0 = drive.trajectorySequenceBuilder(new Pose2d(8.92, -62.06, Math.toRadians(270.00)))
                .setReversed(true)
                .splineToConstantHeading(new Vector2d(8, -30.8), Math.toRadians(90),
                    SampleMecanumDrive.getVelocityConstraint(70, 70, DriveConstants.TRACK_WIDTH),
                    SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .build();

        TrajectorySequence trajectory1 = drive.trajectorySequenceBuilder(new Pose2d(8, -30.8, Math.toRadians(270)))
                .setReversed(false)
                .splineTo(new Vector2d(35.70, -40.06), Math.toRadians(100.00),
                    SampleMecanumDrive.getVelocityConstraint(52, 52, DriveConstants.TRACK_WIDTH),
                    SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .splineToConstantHeading(new Vector2d(35.70, -16.23), Math.toRadians(90.00))
                .splineToConstantHeading(new Vector2d(45.85, -11.56), Math.toRadians(270.00))
                .lineTo(new Vector2d(48.3, -56.8))

                .addDisplacementMarker(2, () -> {
                    extendViperslide(0);
                })
                        .build();

        //start at mismatched position to hardcode for errors
        TrajectorySequence trajectory2 = drive.trajectorySequenceBuilder(new Pose2d(48.3, -49.5, Math.toRadians(90)))
                .splineToLinearHeading(new Pose2d(4.06, -50, Math.toRadians(276.00)), Math.toRadians(90.00))
                .lineToConstantHeading(new Vector2d(4.06, -30),
                    SampleMecanumDrive.getVelocityConstraint(70, 70, DriveConstants.TRACK_WIDTH),
                    SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                        .build();

        TrajectorySequence trajectory3 = drive.trajectorySequenceBuilder(new Pose2d(2.06, -33, Math.toRadians(270)))
                .splineTo(new Vector2d(36, -41), Math.toRadians(95.00))
                .splineToConstantHeading(new Vector2d(36.37, -14), Math.toRadians(90.00))
                .splineToConstantHeading(new Vector2d(54, -8), Math.toRadians(270.00))
                .lineToConstantHeading(new Vector2d(55.6, -55.2),
                    SampleMecanumDrive.getVelocityConstraint(55, 55, DriveConstants.TRACK_WIDTH),
                    SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .addDisplacementMarker(2, () -> {
                    extendViperslide(0);
                })
                        .build();

        TrajectorySequence trajectory4 = drive.trajectorySequenceBuilder(new Pose2d(55.6, -55.4, Math.toRadians(90)))
                .splineToLinearHeading(new Pose2d(0, -45, Math.toRadians(276.00)), Math.toRadians(90.00))
                .lineToConstantHeading(new Vector2d(0, -28.5),
                        SampleMecanumDrive.getVelocityConstraint(70, 70, DriveConstants.TRACK_WIDTH),
                        SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .build();


        TrajectorySequence trajectory5 = drive.trajectorySequenceBuilder(new Pose2d(0, -28.5, Math.toRadians(270)))
                .splineToLinearHeading(new Pose2d(52, -40, Math.toRadians(90)), Math.toRadians(90))
                .lineToConstantHeading(new Vector2d(52, -56.2))
                .addDisplacementMarker(2, () -> {
                    extendViperslide(0);
                })
                        .build();

        TrajectorySequence trajectory6 = drive.trajectorySequenceBuilder(new Pose2d(52, -56.2, Math.toRadians(90)))
                .splineToLinearHeading(new Pose2d(-2, -40, Math.toRadians(276.00)), Math.toRadians(90.00))
                .lineToConstantHeading(new Vector2d(-2, -28.2),
                        SampleMecanumDrive.getVelocityConstraint(70, 70, DriveConstants.TRACK_WIDTH),
                        SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .build();

        TrajectorySequence trajectory7 = drive.trajectorySequenceBuilder(new Pose2d(-2, -28.2, Math.toRadians(270.00)))
                .lineToLinearHeading(new Pose2d(35, -45, Math.toRadians(-45)),
                    SampleMecanumDrive.getVelocityConstraint(75, 75, DriveConstants.TRACK_WIDTH),
                    SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .addDisplacementMarker(2, () -> {
                    extendViperslide(0);
                })
                .build();

        extendViperslide(0);

        retractExtensionServos();
        flipIntakeUp();
        closeOutputClaw();

        waitForStart();

        flipOutputSpecimenOut();
        extendViperslide(1100);
        flipOutputSpecimenOut();
        sleep(500);
        drive.followTrajectorySequence(trajectory0);
        openOutputClaw();
        flipOutputOut();
        drive.followTrajectorySequence(trajectory1);
        closeOutputClaw();
        sleep(200);
        extendViperslide(1100);
        flipOutputSpecimenOut();
        drive.followTrajectorySequence(trajectory2);
        openOutputClaw();
        flipOutputOut();
        drive.followTrajectorySequence(trajectory3);
        closeOutputClaw();
        sleep(200);
        extendViperslide(1100);
        flipOutputSpecimenOut();
        drive.followTrajectorySequence(trajectory4);
        openOutputClaw();
        flipOutputOut();
        drive.followTrajectorySequence(trajectory5);
        closeOutputClaw();
        sleep(200);
        extendViperslide(1100);
        flipOutputSpecimenOut();
        drive.followTrajectorySequence(trajectory6);
        openOutputClaw();
        extendExtensionServos();
        flipIntakePartialDown();
        intakeWrist.setPosition(0.75);
        drive.followTrajectorySequence(trajectory7);

        //numbers are not exact, change later


    }
}