package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.drive.DriveConstants;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;

@Config
@Autonomous
public class LeftAutonomous extends LinearOpMode {
    private DcMotor rightViperslide, leftViperslide;

    // Servos
    private Servo leftExtension, rightExtension, intakeClaw, rightIntakeFlipper, leftIntakeFlipper, slapshot;
    private Servo leftVSFlipper, rightVSFlipper, outputClawLeft, outputClawRight, outputWrist, intakeWrist;

    private double viperslideInitialPosition;

    public void closeOutputClaw() {
        outputClawRight.setPosition(0.67);
        outputClawLeft.setPosition(0.33);
    }
    public void openOutputClaw() {
        outputClawRight.setPosition(0.9);
        outputClawLeft.setPosition(0.1);
    }
    public void retractExtensionServos() {
        leftExtension.setPosition(0.07);
        rightExtension.setPosition(0.95);
    }
    public void flipIntakeUp() {
        leftIntakeFlipper.setPosition(0.94); //flip intake up
        rightIntakeFlipper.setPosition(0.06);
        intakeWrist.setPosition(0.08);
    }
    public void closeIntakeClaw() {
        intakeClaw.setPosition(0.5);
    }
    public void openIntakeClaw() {
        intakeClaw.setPosition(0.8);
    }
    public void flipOutputOut() {
        outputWrist.setPosition(0.41);
        leftVSFlipper.setPosition(0); //flip output claw half
        //sleep(12);
        rightVSFlipper.setPosition(0.84);
    }
    public void flipOutputIn() {
        closeOutputClaw();
        outputWrist.setPosition(0.6);
        leftVSFlipper.setPosition(0.54);
        //sleep(12);
        rightVSFlipper.setPosition (0.3);
    }
    public void flipOutputSpecimenOut() {
        outputWrist.setPosition(0.61);
        leftVSFlipper.setPosition(0.03); //flip output claw half
        //sleep(12);
        rightVSFlipper.setPosition(0.81); //+0.04
    }
    public void flipOutputBucketOut() {
        outputWrist.setPosition(0.19);
        leftVSFlipper.setPosition(0.27);
        //sleep(12);
        rightVSFlipper.setPosition(0.65);
    }
    public void extendExtensionServos() {
        leftExtension.setPosition(0.32);
        rightExtension.setPosition(0.7);
    }
    public void flipIntakeDown() {
        leftIntakeFlipper.setPosition(0.04); //flip intake down
        rightIntakeFlipper.setPosition(0.96);
    }
    public void flipIntakePartialDown() {
        leftIntakeFlipper.setPosition(0.17); //flip intake partial down
        rightIntakeFlipper.setPosition(0.83);
    }
    public void extendViperslide(int targetPosition) {
        rightViperslide.setTargetPosition((int)viperslideInitialPosition + targetPosition);
        leftViperslide.setTargetPosition((int)viperslideInitialPosition + targetPosition);
        rightViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightViperslide.setPower(0.8);
        leftViperslide.setPower(0.8);
    }

    public void flipIntakeSystemOut(double intakeWristPosition) {
        extendViperslide(0);
        extendExtensionServos();
        flipIntakePartialDown(); //flip intake claw semi-down
        intakeWrist.setPosition(intakeWristPosition);
        openIntakeClaw();
    }

    public void retractTransferSequence() {
        flipIntakeDown();
        sleep(300);
        closeIntakeClaw(); //close intake claw
        flipOutputIn();
        openOutputClaw();
        sleep(200);
        flipIntakeUp(); //flip intake claw up
        sleep(700);
        retractExtensionServos();
        sleep(400);
        closeOutputClaw();
        sleep(200);
        openIntakeClaw();  //open input claw
        sleep(200);
        leftExtension.setPosition(0.11); //barely extend horizontal system
        rightExtension.setPosition(0.91);
    }

    @Override
    public void runOpMode() throws InterruptedException {
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap, 0.4);
        rightViperslide = hardwareMap.get(DcMotor.class, "rightViperslide");
        leftViperslide = hardwareMap.get(DcMotor.class, "leftViperslide");

        leftViperslide.setDirection(DcMotor.Direction.REVERSE);

        outputClawLeft = hardwareMap.get(Servo.class, "outputClawLeft");
        outputClawRight = hardwareMap.get(Servo.class, "outputClawRight");
        rightVSFlipper = hardwareMap.get(Servo.class, "rightVSFlipper");
        leftVSFlipper = hardwareMap.get(Servo.class, "leftVSFlipper");
        leftExtension = hardwareMap.get(Servo.class, "leftExtension");
        rightExtension = hardwareMap.get(Servo.class, "rightExtension");
        rightIntakeFlipper = hardwareMap.get(Servo.class, "rightIntakeFlipper");
        leftIntakeFlipper = hardwareMap.get(Servo.class, "leftIntakeFlipper");
        intakeClaw = hardwareMap.get(Servo.class, "intakeClaw");
        slapshot = hardwareMap.get(Servo.class, "slapshot");
        intakeWrist = hardwareMap.get(Servo.class, "intakeWrist");
        outputWrist = hardwareMap.get(Servo.class, "outputWrist");


        // Set viper slide motors to hold position
        rightViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        leftViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        leftViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        viperslideInitialPosition = rightViperslide.getCurrentPosition();






        Pose2d startPose = new Pose2d(-34.57, -62.59, Math.toRadians(0));
        drive.setPoseEstimate(startPose);

        TrajectorySequence trajectory0 = drive.trajectorySequenceBuilder(new Pose2d(-34.57, -62.59, Math.toRadians(0.00)))
                .lineToLinearHeading(new Pose2d(-47.7, -62.5, Math.toRadians(15)))
                .build();

        TrajectorySequence trajectory1 = drive.trajectorySequenceBuilder(new Pose2d(-47.7, -62.5, Math.toRadians(15.00)))
                .splineToLinearHeading(new Pose2d(-51.5, -45.7, Math.toRadians(95.20)), Math.toRadians(123.14),
                    SampleMecanumDrive.getVelocityConstraint(52, 52, DriveConstants.TRACK_WIDTH),
                    SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .build();

        TrajectorySequence trajectory2 = drive.trajectorySequenceBuilder(new Pose2d(-51.5, -45.7, Math.toRadians(90.00)))
                .lineToLinearHeading(new Pose2d(-51.80, -56, Math.toRadians(40.00)),
                        SampleMecanumDrive.getVelocityConstraint(52, 52, DriveConstants.TRACK_WIDTH),
                        SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .build();

        TrajectorySequence trajectory3 = drive.trajectorySequenceBuilder(new Pose2d(-51.8, -56, Math.toRadians(40.00)))
                .splineToLinearHeading(new Pose2d(-62.31, -46.69, Math.toRadians(96.00)), Math.toRadians(109.09))
                .build();

        TrajectorySequence trajectory4 = drive.trajectorySequenceBuilder(new Pose2d(-62.31, -46.69, Math.toRadians(90.00)))
                .lineToLinearHeading(new Pose2d(-56.59, -50.30, Math.toRadians(55.00)))
                .build();

        TrajectorySequence trajectory5 = drive.trajectorySequenceBuilder(new Pose2d(-62.31, -46.69, Math.toRadians(55.00)))
                .lineTo(new Vector2d(-50, -31))
                        .build();

        extendViperslide(0);

        retractExtensionServos();
        flipIntakeUp();
        closeOutputClaw();

        waitForStart();
        flipOutputBucketOut();
        extendViperslide(3950);
        sleep(2000);
        drive.followTrajectorySequence(trajectory0);
        openOutputClaw();
        sleep(400);
        flipOutputIn();
        sleep(100);
        flipIntakeSystemOut(0.75);
        drive.followTrajectorySequence(trajectory1);
        retractTransferSequence();
        sleep(200);
        extendViperslide(3950);
        flipOutputBucketOut();
        sleep(2200);
        drive.followTrajectorySequence(trajectory2);
        openOutputClaw();
        sleep(400);
        flipOutputIn();
        sleep(100);
        drive.followTrajectorySequence(trajectory3);
        sleep(300);
        flipIntakeSystemOut(0.75);
        sleep(1500);
        retractTransferSequence();
        sleep(200);
        extendViperslide(3950);
        flipOutputBucketOut();
        sleep(2200);
        drive.followTrajectorySequence(trajectory4);
        openOutputClaw();
        sleep(400);
        flipOutputIn();
        sleep(100);
        drive.followTrajectorySequence(trajectory5);
        sleep(400);
        extendViperslide(0);
        retractExtensionServos();
        sleep(300);
        openOutputClaw();
        sleep(3700);
    }
}
