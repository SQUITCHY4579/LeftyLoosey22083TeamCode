package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.drive.DriveConstants;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;

@Config
@Autonomous
public class RightAutonomous extends LinearOpMode {
    private DcMotor rightViperslide, leftViperslide;

    // Servos
    private Servo outputClawLeft, outputClawRight, rightVSFlipper, leftVSFlipper;
    private Servo leftExtension, rightExtension, intakeFlipper, intakeClaw;

    private double viperslideInitialPosition;

    public void openOutputClaw() {
        outputClawRight.setPosition(0.67);
        outputClawLeft.setPosition(0.33);
    }

    public void closeOutputClaw() {
        outputClawRight.setPosition(0.9);
        outputClawLeft.setPosition(0.1);
    }

    public void retractExtensionServos() {
        leftExtension.setPosition(0.07);
        rightExtension.setPosition(0.95);
    }

    public void flipIntakeUp() {
        intakeFlipper.setPosition(0.05);
    }

    public void openIntakeClaw() {
        intakeClaw.setPosition(0.18);
    }

    public void closeIntakeClaw() {
        intakeClaw.setPosition(0.04);
    }

    public void flipOutputOut() {
        leftVSFlipper.setPosition(0);
        sleep(12);
        rightVSFlipper.setPosition(0.86);
    }

    public void flipOutputIn() {
        leftVSFlipper.setPosition(0.78);
        sleep(12);
        rightVSFlipper.setPosition(0.06);
    }

    public void flipOutputPartialOut() {
        leftVSFlipper.setPosition(0.1); //flip output claw half
        sleep(12);
        rightVSFlipper.setPosition(0.76);
    }

    public void extendExtensionServos() {
        leftExtension.setPosition(0.32);
        rightExtension.setPosition(0.7);
    }

    public void flipIntakeDown() {
        intakeFlipper.setPosition(0.95);
    }

    public void flipIntakePartialDown() {
        intakeFlipper.setPosition(0.84);
    }

    public void extendViperslide(int targetPosition) {
        rightViperslide.setTargetPosition((int) viperslideInitialPosition + targetPosition);
        leftViperslide.setTargetPosition((int) viperslideInitialPosition + targetPosition);
        rightViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightViperslide.setPower(0.6);
        leftViperslide.setPower(0.6);
    }

    @Override
    public void runOpMode() throws InterruptedException {
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap, 0.5);
        rightViperslide = hardwareMap.get(DcMotor.class, "rightViperslide");
        leftViperslide = hardwareMap.get(DcMotor.class, "leftViperslide");

        leftViperslide.setDirection(DcMotor.Direction.REVERSE);

        outputClawLeft = hardwareMap.get(Servo.class, "outputClawLeft");
        outputClawRight = hardwareMap.get(Servo.class, "outputClawRight");
        rightVSFlipper = hardwareMap.get(Servo.class, "rightVSFlipper");
        leftVSFlipper = hardwareMap.get(Servo.class, "leftVSFlipper");
        leftExtension = hardwareMap.get(Servo.class, "leftExtension");
        rightExtension = hardwareMap.get(Servo.class, "rightExtension");
        intakeFlipper = hardwareMap.get(Servo.class, "intakeFlipper");
        intakeClaw = hardwareMap.get(Servo.class, "intakeClaw");

        // Set viper slide motors to hold position
        rightViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        leftViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        leftViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        viperslideInitialPosition = rightViperslide.getCurrentPosition();


        Pose2d startPose = new Pose2d(8.52, -62.06, Math.toRadians(270.00));
        drive.setPoseEstimate(startPose);

        TrajectorySequence trajectory0 = drive.trajectorySequenceBuilder(new Pose2d(8.52, -62.06, Math.toRadians(270.00)))
                .setReversed(true)
                .splineToConstantHeading(new Vector2d(6.69, -38.55), Math.toRadians(94.90))
                .build();

        TrajectorySequence trajectory1 = drive.trajectorySequenceBuilder(new Pose2d(6.69, -38.55, Math.toRadians(270.00)))
                .setReversed(false)
                .splineToSplineHeading(new Pose2d(6.69, -46.54, Math.toRadians(300)), Math.toRadians(94.90))
                .addDisplacementMarker(26, () -> {
                    // This marker runs after the first splineTo()
                    extendViperslide(0);
                    flipOutputPartialOut();
                    // Run your action in here!
                })
                .build();

        TrajectorySequence trajectory2 = drive.trajectorySequenceBuilder(new Pose2d(6.69, -46.54, Math.toRadians(300)))
                .splineToConstantHeading(new Vector2d(12.57, -40.97), Math.toRadians(-5.08))
                .splineToLinearHeading(new Pose2d(34.42, -38.13, Math.toRadians(0.00)), Math.toRadians(17.60))

                .lineToConstantHeading(new Vector2d(34.86, -6.64))
                .splineToConstantHeading(new Vector2d(41.39, -6.65), Math.toRadians(40))
                .lineToConstantHeading(new Vector2d(43.98, -49.8))
                .splineToConstantHeading(new Vector2d(45.78, -7.30), Math.toRadians(60))
                .splineToConstantHeading(new Vector2d(50.70, -6.90), Math.toRadians(0))
                .lineToConstantHeading(new Vector2d(50.10, -50.2))
                .build();

        TrajectorySequence trajectory3 = drive.trajectorySequenceBuilder(new Pose2d(50.1, -51.2, Math.toRadians(0)))

                .splineToLinearHeading(new Pose2d(46.25, -43.48, Math.toRadians(95.00)), Math.toRadians(114.23),
                        SampleMecanumDrive.getVelocityConstraint(40, 40, DriveConstants.TRACK_WIDTH),
                        SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .splineToLinearHeading(new Pose2d(48.7, -57.23, Math.toRadians(95.00)), Math.toRadians(90),
                        SampleMecanumDrive.getVelocityConstraint(15, 15, DriveConstants.TRACK_WIDTH),
                        SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .build();

        TrajectorySequence trajectory4 = drive.trajectorySequenceBuilder(new Pose2d(48.7, -57.23, Math.toRadians(95.00)))
                .splineToLinearHeading(new Pose2d(0, -48.05, Math.toRadians(273)), Math.toRadians(90.0),
                        SampleMecanumDrive.getVelocityConstraint(30, 30, DriveConstants.TRACK_WIDTH),
                        SampleMecanumDrive.getAccelerationConstraint(DriveConstants.MAX_ACCEL))
                .addDisplacementMarker(2, () -> {
                    extendViperslide(2220);
                })
                .lineToConstantHeading(new Vector2d(0, -40.5))
                .build();

        extendViperslide(0);

        retractExtensionServos();
        flipIntakeUp();
        closeOutputClaw();
        flipOutputPartialOut();

        waitForStart();

        extendViperslide(2260);
        flipOutputOut();
        sleep(950);
        drive.followTrajectorySequence(trajectory0);
        extendViperslide(1400);
        sleep(400);
        openOutputClaw();
        sleep(200);
        drive.followTrajectorySequence(trajectory1);
        drive.followTrajectorySequence(trajectory2);
        drive.followTrajectorySequence(trajectory3);
        closeOutputClaw();
        sleep(300);
        extendViperslide(1000);
        flipOutputOut();
        sleep(800);
        drive.followTrajectorySequence(trajectory4);
        extendViperslide(1400);
        sleep(500);
        openOutputClaw();
        sleep(200);
        extendViperslide(0);
        closeOutputClaw();
        sleep(1100);

        //numbers are not exact, change later


    }
}
