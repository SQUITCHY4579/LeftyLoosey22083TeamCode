package org.firstinspires.ftc.teamcode.drive.opmode;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.drive.DriveConstants;
import org.firstinspires.ftc.teamcode.drive.SampleMecanumDrive;
import org.firstinspires.ftc.teamcode.trajectorysequence.TrajectorySequence;

@Config
@Autonomous
public class LeftAutonomous extends LinearOpMode {
    private DcMotor rightViperslide, leftViperslide;

    // Servos
    private Servo outputClawLeft, outputClawRight, rightVSFlipper, leftVSFlipper;
    private Servo leftExtension, rightExtension, intakeFlipper, intakeClaw;

    private double viperslideInitialPosition;

    public void openOutputClaw() {
        outputClawRight.setPosition(0.67);
        outputClawLeft.setPosition(0.33);
    }
    public void closeOutputClaw() {
        outputClawRight.setPosition(0.9);
        outputClawLeft.setPosition(0.1);
    }
    public void retractExtensionServos() {
        leftExtension.setPosition(0.07);
        rightExtension.setPosition(0.95);
    }
    public void flipIntakeUp() {
        intakeFlipper.setPosition(0.05);
    }
    public void openIntakeClaw() {
        intakeClaw.setPosition(0.18);
    }
    public void closeIntakeClaw() {
        intakeClaw.setPosition(0.04);
    }
    public void flipOutputOut() {
        leftVSFlipper.setPosition(0);
        sleep(12);
        rightVSFlipper.setPosition (0.86);
    }
    public void flipOutputIn() {
        leftVSFlipper.setPosition(0.78);
        sleep(12);
        rightVSFlipper.setPosition (0.06);
    }
    public void flipOutputPartialOut() {
        leftVSFlipper.setPosition(0.06); //flip output claw half
        sleep(12);
        rightVSFlipper.setPosition(0.8);
    }
    public void extendExtensionServos() {
        leftExtension.setPosition(0.32);
        rightExtension.setPosition(0.7);
    }
    public void flipIntakeDown() {
        intakeFlipper.setPosition(0.95);
    }
    public void flipIntakePartialDown() {
        intakeFlipper.setPosition(0.84);
    }
    public void extendViperslide(int targetPosition) {
        rightViperslide.setTargetPosition((int)viperslideInitialPosition + targetPosition);
        leftViperslide.setTargetPosition((int)viperslideInitialPosition + targetPosition);
        rightViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        leftViperslide.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        rightViperslide.setPower(0.6);
        leftViperslide.setPower(0.6);
    }

    @Override
    public void runOpMode() throws InterruptedException {
        SampleMecanumDrive drive = new SampleMecanumDrive(hardwareMap);
        rightViperslide = hardwareMap.get(DcMotor.class, "rightViperslide");
        leftViperslide = hardwareMap.get(DcMotor.class, "leftViperslide");

        leftViperslide.setDirection(DcMotor.Direction.REVERSE);

        outputClawLeft = hardwareMap.get(Servo.class, "outputClawLeft");
        outputClawRight = hardwareMap.get(Servo.class, "outputClawRight");
        rightVSFlipper = hardwareMap.get(Servo.class, "rightVSFlipper");
        leftVSFlipper = hardwareMap.get(Servo.class, "leftVSFlipper");
        leftExtension = hardwareMap.get(Servo.class, "leftExtension");
        rightExtension = hardwareMap.get(Servo.class, "rightExtension");
        intakeFlipper = hardwareMap.get(Servo.class, "intakeFlipper");
        intakeClaw = hardwareMap.get(Servo.class, "intakeClaw");

        // Set viper slide motors to hold position
        rightViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        leftViperslide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        leftViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        rightViperslide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        viperslideInitialPosition = rightViperslide.getCurrentPosition();






        Pose2d startPose = new Pose2d(-8.52, -62.06, Math.toRadians(270.00));
        drive.setPoseEstimate(startPose);

        TrajectorySequence trajectory0 = drive.trajectorySequenceBuilder(new Pose2d(-8.52, -62.06, Math.toRadians(270.00)))
                .setReversed(true)
                .splineToConstantHeading(new Vector2d(-6.69, -38.55), Math.toRadians(94.90))
                .build();



        TrajectorySequence trajectory1 = drive.trajectorySequenceBuilder(new Pose2d(-6.69, -38.55, Math.toRadians(270.00)))
                .setReversed(false)
                .splineToConstantHeading(new Vector2d(-20, -43.05), Math.toRadians(94.90))
                .build();


        extendViperslide(0);

        retractExtensionServos();
        flipIntakeUp();
        closeOutputClaw();
        flipOutputPartialOut();

        waitForStart();
        sleep(8500);

        extendViperslide(2260);
        flipOutputOut();
        sleep(900);
        drive.followTrajectorySequence(trajectory0);
        extendViperslide(1400);
        sleep(400);
        openOutputClaw();
        sleep(600);
        extendViperslide(0);
        sleep(1000);
        drive.followTrajectorySequence(trajectory1);
    }
}
