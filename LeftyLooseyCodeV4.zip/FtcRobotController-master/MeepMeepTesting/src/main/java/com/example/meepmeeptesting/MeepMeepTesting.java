package com.example.meepmeeptesting;

import com.acmerobotics.roadrunner.geometry.Pose2d;
import com.acmerobotics.roadrunner.geometry.Vector2d;
import com.acmerobotics.roadrunner.trajectory.Trajectory;

import org.rowlandhall.meepmeep.MeepMeep;
import org.rowlandhall.meepmeep.roadrunner.DefaultBotBuilder;
import org.rowlandhall.meepmeep.roadrunner.entity.RoadRunnerBotEntity;

public class MeepMeepTesting {
    public static void main(String[] args) {
        MeepMeep meepMeep = new MeepMeep(700);



        RoadRunnerBotEntity myBot = new DefaultBotBuilder(meepMeep)
                // Set bot constraints: maxVel, maxAccel, maxAngVel, maxAngAccel, track width

                .setConstraints(52, 52, Math.toRadians(231.31152), Math.toRadians(231.31152), 11.55)
                .followTrajectorySequence(drive -> drive.trajectorySequenceBuilder(new Pose2d(7.71, -65.10, Math.toRadians(270.00)))
                        .setReversed(false)
                        .lineToConstantHeading(new Vector2d(6.08, -34.07))
                        .splineToConstantHeading(new Vector2d(10, -40), Math.toRadians(89.60))
                        .splineToSplineHeading(new Pose2d(36.30, -43.81, Math.toRadians(90.00)), Math.toRadians(-90))
                        .splineToConstantHeading(new Vector2d(35.70, -11.15), Math.toRadians(89.60))



                        .build());



        meepMeep.setBackground(MeepMeep.Background.FIELD_INTOTHEDEEP_JUICE_DARK)
                .setDarkMode(true)
                .setBackgroundAlpha(0.95f)
                .addEntity(myBot)
                .start();
    }
}